# cloud_function/main.py
def hello_world(request):
    return "Hello from Cloud Function!"
